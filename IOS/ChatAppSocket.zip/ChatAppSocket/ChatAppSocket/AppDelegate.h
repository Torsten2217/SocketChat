//
//  AppDelegate.h
//  ChatAppSocket
//
//  Created by Juseman on 10/03/15.
//  Copyright (c) 2015 azizdev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

